import React, { Component } from 'react';
import Navbar_new from "./navbar_new";
import { Field, reduxForm } from "redux-form";


class Signup2 extends Component{

    









}